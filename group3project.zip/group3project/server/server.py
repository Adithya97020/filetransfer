#!/usr/bin/python
import sys
from Crypto.Hash import SHA256
import ssl
import random
import socket

def main():
    if len(sys.argv) != 5:                    #There are five arguments which the server needs to enter. So if the server does not enter 5 arguments, then exit
        print_usage_and_exit();
    try:
        port = int(sys.argv[1])               #The first argument is the port number
    except ValueError:
        print 'invalid port: ' + sys.argv[1]
        print_usage_and_exit()

    private_key_filename = sys.argv[2]        #The third argument is the server private key
    server_cert_filename = sys.argv[3]        #The fourth argument is the server certificate file
    ca_cert_filename = sys.argv[4]            #The fifth argument is the CA root certificate file
    
    sock = open_tls_socket(port, private_key_filename, server_cert_filename, ca_cert_filename)   #TLS socket
    process_connections(sock)


def open_tls_socket(port, private_key, server_cert, ca_cert):

    try: 
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)            #Create an INET, STREAMing socket
        sock.bind(('', port))                                               #Bind to the port number 
        sock.listen(2)

        tls_sock = ssl.wrap_socket(sock, keyfile=private_key, certfile=server_cert, server_side=True, cert_reqs=ssl.CERT_REQUIRED, 
            ssl_version=ssl.PROTOCOL_TLSv1_2, ca_certs=ca_cert, do_handshake_on_connect=True, suppress_ragged_eofs=True)
    except ssl.SSLError as (e, msg):
        print "TLS socket error (likely wrong keys/certs): " + msg
        exit(1)
    except socket.error as (e, msg):
        print "socket error: " + msg
        exit(1)
    except IOError as (e, msg):
        print "error opening file: " + msg
        exit(1)
    except Exception as (e, msg):
        print "unexpected error opening socket: " + msg
        exit(1)

    return tls_sock


def process_connections(sock):
    while (True):
        try:
            connection, client_addr = sock.accept()
        except ssl.SSLError as e:
            print 'error accepting TLS connection: ' + e.reason
            continue
        except KeyboardInterrupt:
            print 'Quitting!'
            try:
                connection.close()          
            except:
                pass
            exit(0)
        except Exception as (e, msg):
            print e
            continue
        
        while True:
            try:
                mode = connection.recv(1024)
                if mode.startswith("put"):
                    put(connection, mode)
                elif mode.startswith("get"):
                    get(connection, mode)
                elif mode.startswith("stop"):
                    try: 
                        connection.close()
                    except:
                        pass
                    break
                else:
                    print 'unknown command from client: ' + mode
                    continue
            except:
                print 'error occured communicating with client, closing connection'
                try: 
                    connection.close()
                except:
                    pass
                break
        print 'ended connection with client'

def put(conn, mode):
    try:
        conn.sendall("put ok")
        path = mode.split()[1]
        filename = path.split("/")[-1]

        hsh = conn.recv(1024)

        try:
            with open(filename+".sha256", 'wb') as f:                          #Write the hash to the directory in the disk
                f.write(hsh)
        except:
            conn.sendall("hsh fail")                                           #except for cannot write
            return

        conn.sendall("hsh ok")

        blocknum = int(conn.recv(1024))
        conn.sendall("block ok")
        text = None
        while blocknum >= 0:
            if not text:
                text = conn.recv(4096)
            else:
                text += conn.recv(4096)
            blocknum -= 1

        try:
            with open(filename, 'wb') as f:                                    #Write the file to the directory in the disk
                f.write(text)
        except:
            conn.sendall("write fail")                                         #except for cannot write
            return

        conn.sendall("write ok")
        print("File "+filename+" written to disk")
    except socket.error:
        print("Connection to remote host was lost. Put could not be completed")


def get(conn, mode):
    try:
        filename = mode.split()[1]
        try:
            with open(filename, 'rb') as f:
                data = f.read()
            with open(filename+".sha256", 'rb') as f:
                hsh = f.read()
        except:
            conn.sendall("badreq")
            return
        conn.sendall("get ok")
        resp = conn.recv(1024)
        conn.sendall(hsh)                                                          #The server sends the hash to the client
        resp = conn.recv(1024)
        blocknum = int(sys.getsizeof(data) / 4096)
        conn.sendall(str(blocknum))
        resp = conn.recv(1024)
        while blocknum >= 0:                                                       #The server sends the file to the server
            conn.sendall(data[:4096])
            data = data[4096:]
            blocknum -= 1
    except socket.error:
        print("Connection to remote host was lost. Get could not be completed")



def print_usage_and_exit():
    print 'Usage:'
    print '\t$ server <port> </path/to/server/private/key> </path/to/server/cert> </path/to/ca/root/cert>'
    exit(1)

if __name__ == "__main__":
    main()
