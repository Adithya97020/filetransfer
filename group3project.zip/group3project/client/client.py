#!/usr/bin/python
import sys
import os
from Crypto.Hash import SHA256
from Crypto import Random
from Crypto.Cipher import AES
import ssl
import random
import socket
from binascii import hexlify
import struct
import hashlib

def main():
    if len(sys.argv) != 6:                       #There are six arguments which the client needs to enter. So if the client does not enter 6 arguments, then exit
        print_usage_and_exit();

    try:
        host = sys.argv[1]                       #The first argument is the server ip address
        server_ip = socket.gethostbyname(host)
    except:
        print "can't find IP for host " + host   #If the ip address is not entered, then exit 
        exit(1)

    try:
        port = int(sys.argv[2])                  #The second argument is the port number
    except:
        print 'invalid port: ' + sys.argv[2]     #If the port is invalid or not entered, then exit
        print_usage_and_exit()

    private_key_filename = sys.argv[3]           #The third argument is the client private key file
    client_cert_filename = sys.argv[4]           #The fourth argument is the client certificate file
    ca_cert_filename = sys.argv[5]               #The fifth argument is the CA root certificate file

    s = connect_to_server(server_ip, port, private_key_filename, client_cert_filename, ca_cert_filename)          #TLS socket

    while True: #continues taking commands until
        usr_in = raw_input("Enter a command: ")  #Take user input
        if usr_in.startswith("put"):             #If the user input begins with put then execute the put function and pass the TLS socket and the user input
            put(s, usr_in)
        elif usr_in.startswith("get"):           #If the user input begins with get then execute the get function and pass the TLS socket and the user input 
            get(s, usr_in)
            #pass #for now
        elif usr_in.startswith("stop"):          #If user inputs stop then print Goodbye and call the stop function         
            print("Goodbye")
            stop(s)
            quit()
        else:
            print("Command not recognized. Valid commands are put, get, and stop.")       #If user inputs anything else other than the ones mentioned above, then print the statement as mentioned on the left

def connect_to_server(server_addr, server_port, client_private_key, client_cert, ca_cert):
    try:
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)                          #Create an INET, STREAMing socket
    except IOError as e:                                                                  #If an exception occurs then the error message is printed
        print 'error opening socket: ' + e.reason
        exit(1)

    try: 
        tls_sock = ssl.wrap_socket(sock, keyfile=client_private_key, certfile=client_cert, server_side=False, 
            cert_reqs=ssl.CERT_REQUIRED, ssl_version=ssl.PROTOCOL_TLSv1_2, ca_certs=ca_cert, do_handshake_on_connect=True, suppress_ragged_eofs=True)    #Wrap the existing socket sock and return the ssl object. The returned ssl socket is tied to the context, its settings and certificates
        tls_sock.connect((server_addr, server_port))                                      #Connect the socket to the server address and the server port
    except ssl.SSLError as (e, msg):
        print 'error initiating TLS connection: ' + msg                                   #Exception for TLS connection error
        exit(1)
    except socket.error as (e, msg):
        print 'error connecting socket: ' + msg                                           #Exception for socket connection error
        exit(1)
    except IOError as (e, msg):
        print "error opening file: " + msg                                                #Exception if cannot open file
        exit(1)
    except Exception as (e, msg):
        print "unexpected error opening socket: " + msg                                   #Exception if any error other than above
        exit(1)

    return tls_sock

def get(sock, usr_in):
    params = usr_in.split(" ")                                                            #The arguments which the user inputs are stored in a list params 
    try:
        filename = params[1]                                                              #The first argument is the filename
        flag = params[2]                                                                  #The second argument is the flag E or N
        if flag == 'E':
            password = params[3]                                                          #If the flag is E, then the third parameter is the password
            assert len(password) == 8                                                     #Make sure length of password is 8 characters
        else:
            assert flag == 'N'                                                            #Make sure if user does not enter E, then the user should enter N
            try:
                if len(params[3]) == 8:
                    while True:
                        ans = raw_input("You entered a password for unencrypted mode. Did you mean to use encrypted mode? (Y/n)\n")
                        if ans == "Y":
                            flag = 'E'
                            password = params[3]
                            break
                        elif ans == 'n':
                            break
            except IndexError:                                                            #If list index is out of range, then pass                                                           
                pass

    except (IndexError, AssertionError):                                                  
        print("Please specify a filename, flag that is E or N, and, if the flag is E, an 8-character password")
        return

    try:
        sock.sendall("get "+filename)                                                     #Client sends a request to the server asking for a file
        resp = sock.recv(1024)                                                            #The client gets a reply from the server saying that whether the request is bad or ok
        if resp == "badreq":                    
            print("The file cannot be retrieved. Get failed.")
            return
        sock.sendall("ack")                                                               
        h = sock.recv(1024)                                                               #The client receives the hash of the requested file from the server
        sock.sendall("ack")
        blocknum = int(sock.recv(1024))                                                   #The client receives the size of the requested file
        sock.sendall("ack")
        data = None
        while blocknum >= 0:                                                              #This is the logic for accepting files through the socket
            if not data:                                                                     
                data = sock.recv(4096)
            else:
                data = data+sock.recv(4096)
            blocknum -= 1
        if flag == 'E':                                                                   #If flag is E, then perform the encryption                                                               
            iv = data[:AES.block_size]                                                    #Extract the IV from the ciphertext
            data = data[AES.block_size:]
            salt = 'some arbitrary value'                                                 #Take salt as some constant
            key = hashlib.pbkdf2_hmac('sha256', bytearray(password), bytearray(salt), 100001, dklen=16)
            cipher = AES.new(key, AES.MODE_CBC, iv)
            try:
                plaintext = cipher.decrypt(data)
            except:
                print("Decryption failed. File was probably not encrypted in the first place.")
                return
            plaintext = plaintext[:-ord(plaintext[-1])]                                   #Unpadding
        else:
            plaintext = data
        hsh = SHA256.new(plaintext)
        hashtext = hsh.digest()                                                           #Generating the hash of the decrypted plaintext
        if hashtext != h:                                                                 #Verify whether the hashes match
            print("Hash verification failed. File will not be written to disk.")
            return
        try:
            with open(filename, 'wb') as f:                                               #Writing the file to the directory in the disk
                f.write(plaintext)
        except:
            print("File was verified, but could not be written to disk")                  
            return

        print(filename+" was verified and written to disk")

    except socket.error:
        print("Connection to the remote host was lost. Get could not be completed")


def put(sock, usr_in):                                                                    
    params = usr_in.split(" ")
    try:
        filepath = params[1]
        flag = params[2]
        if flag == 'E':
            password = params[3]
            assert len(password) == 8
        else:
            assert flag == 'N'
            try:
                if len(params[3]) == 8:
                    while True:
                        ans = raw_input("You entered a password for unencrypted mode. Did you mean to use encrypted mode? (Y/n)\n")
                        if ans == "Y":
                            flag = 'E'
                            password = params[3]
                            break
                        elif ans == 'n':
                            break
            except IndexError:
                pass
    except (IndexError, AssertionError):
        print("Please specify a filepath, flag that is E or N, and, if the flag is E, an 8-character password")
        return

    try:
        with open(filepath, 'rb') as f:
            plaintext = f.read()
    except IOError:
        print("File not found")
        return

    try:
        sock.sendall("put "+filepath)                                                   #gotta tell the server to expect a put
        hsh = SHA256.new(plaintext)
        response = sock.recv(1024)
        if response != "put ok":
            print("something went wrong on the server end")
            return

        hashtext = hsh.digest()                                                         #create the hash
        sock.sendall(hashtext)
        if flag == 'E': 
            salt = 'some arbitrary value'
            key = hashlib.pbkdf2_hmac('sha256', bytearray(password), bytearray(salt), 100001, dklen=16)
            iv = os.urandom(AES.block_size)                                             # generate an IV
            cipher = AES.new(key, AES.MODE_CBC, iv)
            length = 16 - (len(plaintext) % 16)
            plaintext += chr(length) * length

            #code to unpad is plaintext = plaintext[:-plaintext[-1]]
            ciphertext = iv + cipher.encrypt(plaintext)                                 # preappend IV to ciphertext

        else:
            ciphertext = plaintext
        blocknum = int(sys.getsizeof(ciphertext) / 4096)                                # find the number of blocks to send the encrypted file

        resp = sock.recv(1024)
        if resp != "hsh ok":
            print("The hash could not be written to the server. Ensure the filename is not already in use")
            return
        sock.sendall(str(blocknum))

        resp = sock.recv(1024)
        while blocknum >= 0:
            sock.sendall(ciphertext[:4096])
            ciphertext = ciphertext[4096:]
            blocknum -=1
        resp = sock.recv(1024)
        if resp == "write ok":                                                          #should return ok if the file is successfully written to disk
            print(filepath+" was successfully put onto server")
        else:
            print("There was a problem, the file was not written.")
    except socket.error:
        print("Connection to the remote host was lost. Put could not be completed")

def stop(sock):
    try:
        sock.sendall('stop')                                                            
        sock.close()
    except:
        print 'Error occurred disconnecting from server, server is probably confused now'

def print_usage_and_exit():
    print 'Usage:'
    print '\t$ client <server addr> <server port> </path/to/client/private/key> </path/to/client/cert> </path/to/ca/root/cert>'
    exit(1)

if __name__ == "__main__":
    main()
